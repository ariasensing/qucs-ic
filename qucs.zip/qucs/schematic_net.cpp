/**
 * ARIA Sensing srl
 * Handling of connection and nodes.
 * This is done
 **/
#include <QMap>
#include <QVector>
#include "schematic.h"
#include "settings.h"
#include "textdoc.h"

#include "misc.h"
#include "iclayout.h"
#include "wire.h"
#include "node.h"
/**
 * @brief Schematic::removeConductor. Remove a conductor from the connection set. This function does not
 * check for actual connections. It simply take care of the connection set and the maxId
 * @param cond
 */
void                      Schematic::removeConductor(Conductor* cond)
{
  if (cond == nullptr) return;
  unsigned int id = cond->getNetID();

  if (id==0) return;

  connected_iterator it = m_connection_set.find(id);
  if (it==m_connection_set.end()) return;
  it->removeAll(cond);
  if (it->isEmpty())
    m_connection_set.remove(id);

  // To keep consistency, let's put cond->ID to 0
  cond->setNetID(0);
}
/**
 * @brief Schematic::addConductor Add a conductor to the connection set. This function does not
 * check for actual connections. If conductor id is 0, a new id is assigned
 * @param cond
 */
void                      Schematic::addConductor(Conductor* cond)
{
  if (cond == nullptr) return;
  unsigned int id = cond->getNetID();

  if (id==0)
  { id = get_available_id(); cond->setNetID(id);}

  QVector<Conductor*>& current_set = m_connection_set[id];
  if (std::find( current_set.begin() , current_set.end(), cond)!=current_set.end()) return;
  current_set.emplace_back(cond);
}

/**
 * @brief Schematic::addConductorWithConnectionCheck. Add a conductor to the connection set. This function
 * check current connections and update the connectionSet accordingly
 * @param cond
 */
void                      Schematic::addConductorWithConnectionCheck(Conductor* cond)
{
  if (cond==nullptr) return;

  QVector<Conductor*> current_set;

  cond->getConnectedConductors(current_set);

  unsigned int target_id = 0;
  // If the given conductor does not have a valid id,
  // let's search in the connection
  if (cond->getNetID()==0)
  {
    for (auto c : current_set)
      if (c!=nullptr)
      {
        unsigned int connected_id = c->getNetID();
        if (connected_id > 0)
        { target_id = connected_id; break;}
      }
  }
  else
        target_id = cond->getNetID();

  // If overall we still don't have a valid id, let's assign a new one
  if (target_id == 0)
    target_id = get_available_id();

  // We have found a suitable index: let's assign it to all the elements of the set
  for (auto c: current_set)
  {
    // Update also the id, in case we have a mismatch
    if (c==nullptr) continue;

    unsigned int current_id = c->getNetID();
    if (current_id == target_id) continue;

    // Remove the one from the previous one
    if (current_id)
        removeConductor(c);

    // Set the new id and update
    c->setNetID(target_id);

    addConductor(c);
  }
}

/**
 * @brief Schematic::searchConnectionSets Given a list of conductors, it splits it into a list
 * of connected ones. Note that the output set may contain MORE conductors since all connected
 * are inserted.
 */
QList<QVector<Conductor*>>  Schematic::splitSetAccordingToConnections(QVector<Conductor*> cond_set)
{
  QList<QVector<Conductor*>>  out_list;
  while (!cond_set.isEmpty())
  {
    Conductor* test = cond_set.last();
    cond_set.removeLast();

    if (test==nullptr) continue;

    QVector<Conductor*> current_set;
    test->getConnectedConductors(current_set);

    // Put the current set into the output
    assert(!current_set.isEmpty());
    out_list.emplace_back(current_set);
    // Remove the current set from the inquiry elements
    for (auto c : current_set)
      if (c)
        cond_set.removeAll(c);
  }
  return out_list;
}
/**
 * @brief Schematic::rebuildConnectionAfterDelete
 * @param cond Is the conductor that has been deleted
 */

void                      Schematic::rebuildConnectionAfterDelete(Conductor* cond)
{
  // Cond is the conductor we have delete. Let's find previous connection
  if (cond == nullptr) return;
  unsigned int cond_id = cond->getNetID();

  if (cond_id==0) return;
  removeConductor(cond);
  QVector<Conductor*> connections = m_connection_set[cond_id];

  if (connections.isEmpty()) return;

  // Check for previous connection. Deleting a conductor in between may result in two different subsets.
  // In case, we need to assign a new set (unless they have same label!)
  QList<QVector<Conductor*>> connections_sets = splitSetAccordingToConnections(connections);
  assert(connections_sets.size() > 0 );

  if (connections_sets.size()<2)
  {
    m_connection_set.clear();
    return;
  }
  // Since we are deleting just ONE conductor, we cannot have more than two sets
  //assert(connections_sets.size() == 2 );

  QVector<Conductor*> & set1 = connections_sets[0];
  QVector<Conductor*> & set2 = connections_sets[1];

  if ((set1.isEmpty())||(set2.isEmpty())) return;

  Conductor* cond1 = set1[0];
  Conductor* cond2 = set2[0];
  WireLabel* l1 = cond1->has_global_label();
  WireLabel* l2 = cond2->has_global_label();
  if ((l1!=nullptr)&&(l2!=nullptr)) return;
  bool cond1_is_gnd = cond1->isGnd();
  bool cond2_is_gnd = cond2->isGnd();

  if (cond1_is_gnd && cond2_is_gnd) return;

  if ((l1!=nullptr)||(cond1_is_gnd))
  {
    // Modify only cond2_set
    unsigned int new_id = get_available_id();
    // Remove all conductors of set2
    for (auto c : set2)
      if (c!=nullptr)
        removeConductor(c);

    for (auto c : set2)
      if (c!=nullptr)
        c->setNetID(new_id);

    m_connection_set[new_id] = set2;

    return;
  }

  // Modify only cond1_set
  unsigned int new_id = get_available_id();
  // Remove all conductors of set2
  for (auto c : set1)
    if (c!=nullptr)
      removeConductor(c);

  for (auto c : set1)
    if (c!=nullptr)
      c->setNetID(new_id);

  m_connection_set[new_id] = set1;
  return;
}

void                      Schematic::rebuildConnectionAfterInsertion(Conductor* cond)
{
  // When inserting a new conductor, we may join two different subsets.
  // 1. Retrieve the list of connected conductors. If they have different IDs, the two subsets must be joined
  if (cond == nullptr) return;
  unsigned int cond_id = cond->getNetID();

  if (cond_id==0) return;

  QVector<Conductor*> current_set;
  cond->getConnectedConductors(current_set);
  QSet<unsigned int> id_sets;

  for (auto c: current_set)
    if (c!=nullptr)
      id_sets.insert(c->getNetID());
  // Find the first non-zero id
  unsigned int target_id = 0;
  for (auto id : id_sets)
    if (id > 0) {target_id = id; break;}

  if (target_id==0) target_id = get_available_id();

  // Join all previous
  for (auto c: current_set)
    if (c!=nullptr)
    {
      if (c->getNetID() == target_id) continue;

      removeConductor(c);

      c->setNetID(target_id);

      addConductor(c);
    }
}


/**
 * @brief Schematic::rebuildConnectionAfterSplitting
 * @param cond is the new wire which splits a previous one
 */
void  Schematic::rebuildConnectionAfterSplitting(Conductor* cond)
{
  // We just need to normalize the id and the connection set
  if (cond==nullptr) return;

  QVector<Conductor*> cond_connected;
  cond->getConnectedConductors(cond_connected);

  unsigned int target_id = 0;
  for (auto c : cond_connected)
  {

    if (c==nullptr) continue;
    unsigned int current_id = c->getNetID();

    if (current_id > 0)
    {
      target_id = current_id;
      break;
    }
  }

  // Assign a new one if we don't have yet a valid id
  if (target_id==0) target_id = get_available_id();

  for (auto c: cond_connected)
  {
    if (c== nullptr) continue;

    if (c->getNetID()==target_id) continue;

    removeConductor(c);

    c->setNetID(target_id);

    addConductor(c);
  }


}

/**
 * @brief Schematic::rebuildConnectionAfterLabelInsertion
 * @param cond
 */
void  Schematic::rebuildConnectionAfterLabelInsertion(Conductor* cond)
{
  if (cond==nullptr) return;
  if (!cond->hasLabel()) return;
  QString label_cond = cond->label()->Name;
  // We need to look for any other conductor which share the same label text

  unsigned int target_id = 0;
  unsigned int cond_id = cond->getNetID();
  for (std::list<Wire*>::iterator wit = a_Wires->begin(); wit != a_Wires->end(); wit++)
  {
    Wire* w = *wit;
    if (w==nullptr) continue;
    if (!w->hasLabel()) continue;
    if (w==cond) continue;
    QString other_label = w->label()->Name;

    if (other_label!=label_cond) continue;

    unsigned int wid = w->getNetID();
    // They are already in the same set
    if (wid == cond_id)
      return;

    target_id = wid;
  }
  // There's no other conductor with the same label
  if (target_id == 0) return;

  // Get all the conductors connected to cond
  QVector<Conductor*> set = m_connection_set[cond_id];
  for (auto c : set)
    if (c!=nullptr)
      c->setNetID(target_id);

  m_connection_set.remove(cond_id);
  m_connection_set[target_id].append(set);
}

/**
 * @brief rebuildConnectionAfterLabelRemoval
 */
void  Schematic::rebuildConnectionAfterLabelRemoval(Conductor* cond)
{
  if (cond==nullptr) return;
  if (cond->hasLabel()) return;
  // We removed the label from cond. We need to detach only the set of conductors physically attached to cond
  unsigned int current_id = cond->getNetID();

  // get the current set
  QVector<Conductor*> current_set = m_connection_set[current_id];

  QVector<Conductor*> cond_connected;
  cond->getConnectedConductors(cond_connected);

  if (cond_connected.size()==current_set.size()) return; // There's no left conductor, so don't need to assign a new id
  unsigned int target_id = get_available_id();
  for (auto c: cond_connected)
  {
    if (c!=nullptr)
      removeConductor(c);
    c->setNetID(target_id);
  }

  m_connection_set[target_id] = cond_connected;

}

/**
 * @brief Schematic::get_available_id
 * @return
 */

unsigned int  Schematic::get_available_id()
{
  unsigned int id = 1;
  for (connected_iterator c =  m_connection_set.begin(); c != m_connection_set.end(); c++, id++)
  {
    unsigned int key = c.key();
    if (key > id)
        return id;
  }
  return id;
}

/**
 * @brief Schematic::rebuildConnectionAfterGndInsertion
 */
void    Schematic::rebuildConnectionAfterGndInsertion(Conductor* )
{

}
/**
 * @brief Schematic::rebuildConnectionAfterGndLabelRemoval
 */
void  Schematic::rebuildConnectionAfterGndLabelRemoval(Conductor* )
{

}
